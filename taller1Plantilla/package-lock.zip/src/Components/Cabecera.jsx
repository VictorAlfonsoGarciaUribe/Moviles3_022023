import { useState } from 'react'


function Cabecera() {
  return (
    <div className="p-5 bg-primary text-white text-center">
      <h1>My First Bootstrap 5 Page</h1>
      <p>Resize this responsive page to see the effect!</p> 
    </div>
  )
}

export default Cabecera