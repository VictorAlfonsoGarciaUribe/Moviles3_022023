import React from 'react';

function MainContent() {
  return (
    <div className="col-sm-8">
      <h2>TITLE HEADING</h2>
      <h5>Title description, Dec 7, 2020</h5>
      <div className="fakeimg">Fake Image</div>
      <p>Some text..</p>
      {/* Otras partes del contenido */}
    </div>
  );
}

export default MainContent;