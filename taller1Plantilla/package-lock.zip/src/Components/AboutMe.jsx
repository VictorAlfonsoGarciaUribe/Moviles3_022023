import React from 'react';

function AboutMe() {
  return (
    <div className="col-sm-4">
      <h2>About Me</h2>
      <h5>Photo of me:</h5>
      <div className="fakeimg">Fake Image</div>
      <p>Some text about me in culpa qui officia deserunt mollit anim..</p>
      {/* Otras partes del contenido */}
    </div>
  );
}

export default AboutMe;