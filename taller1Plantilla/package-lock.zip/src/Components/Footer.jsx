import React from 'react';

function Footer() {
  return (
    <div className="mt-5 p-4 bg-dark text-white text-center">
      <p>Footer</p>
    </div>
  );
}

export default Footer;