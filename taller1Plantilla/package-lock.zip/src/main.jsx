import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './Components/App.jsx'

//Aca es donde tengo que renderizar los compónentes que van al index

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />   
  </React.StrictMode>,
)
