import { useState } from 'react'
import Formulario from './Components/Formulario'


function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <h3>Hooks</h3>
    <h5>useState --- se usa para saber el estado actual de la variable</h5>
    <p>Forma normal: Cuando damos click obtiene la información</p>
    <p>Forma controlada: Mientras la persona esta escribiendo obtiene información </p>
    <p>useEffect ---</p>
    <p>useContext ---</p>
    <p>useRef</p>
    <div className='container'>
    <Formulario/>
    </div>
    </>
  )
}

export default App
