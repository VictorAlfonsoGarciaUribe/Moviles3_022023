import React from 'react'

import Pie from '../pie/pie'
import Menu from '../menu/menu'

const Plans = () => {
  return (
    <>
    <Menu/>
    <div>Tourist plans</div>
    <Pie/>
    </>
  )
}

export default Plans