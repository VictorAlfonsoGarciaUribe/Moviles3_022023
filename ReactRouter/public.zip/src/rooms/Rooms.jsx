import React from 'react'


import Pie from '../pie/pie'
import Menu from '../menu/menu'

const Rooms = () => {
  return (
    <>
    <Menu/>
    <div>Rooms</div>
    <Pie/>
    </>
  )
}

export default Rooms