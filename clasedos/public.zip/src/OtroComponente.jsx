

let Contenedor = () => {
    return <h1>Otro componente</h1>
}

export default Contenedor;